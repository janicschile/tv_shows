from django.shortcuts import render, redirect
from app.models import Show
from django.contrib import messages
from django.utils import timezone
from datetime import datetime

# Create your views here.
def index(request):
	context = {
	}
	return redirect(f'/shows')
    
    
def newShow(request):
    context = {
    }
    return render(request, "new_show.html", context)




def createShow(request):
    print(request.POST['date'])
    
    # Agregamos formulario a la BD
    Show.objects.create(
        title = request.POST['title'],
        network=request.POST['network'],
        date=request.POST['date'], 
        description=request.POST['description'])
    
    #Obtenemos ID 
    id = Show.objects.last().id
    showTitle = Show.objects.get(id=id).title

    messagePopup = f'El TV Show "{showTitle}", ha sido creado correctamente'
    print(messagePopup)
    messages.success(request, messagePopup)

    # Redireccion a pagina mostrando los datos ingresados
    return redirect(f'/shows/{id}')




def deleteShow(request, id):
    showTitle = Show.objects.get(id=id).title
    elimina = Show.objects.get(id=id)
    elimina.delete()
    messagePopup = f'Exito al Eliminar el TV Show "{showTitle}"'
    print(messagePopup)
    messages.warning(request, messagePopup)

    return redirect(f'/shows')


def editShow(request, id):

    context = {
        "data_show": Show.objects.get(id=id)
    }
    return render(request, 'edit_show.html', context)


def saveShow(request, id):
    #print(f"AQUI LA FECHA: {request.POST['date']}")
    #
    #print(request.POST['date'])
    #date = f"{request.POST['date']} 00:00:00"
    #print(date)
    #print(datetime.strptime(date, "%Y-%m-%d %H:%M:%S").date())
    #date= request.POST['date']
    #print(f"AQUI LA FECHA: {date}")
    #
    


    
    #print(request.POST['title'])
    #print(id)
    #print(timezone.now())
    #date = timezone.now()

    ##  actualiza.date='2021-08-01T08:08:08-0600',  FORMATO CORRECTO

    print(request.POST['date'])
    
    actualiza = Show.objects.get(id=id)
    actualiza.title = request.POST['title'],
    actualiza.network=request.POST['network'],
    actualiza.date=request.POST['date'], 
    actualiza.description=request.POST['description']
    actualiza.save()
    showTitle = request.POST['title']
    messagePopup = f'Exito al Modificar el TV Show "{showTitle}"'
    print(messagePopup)
    messages.success(request, messagePopup)
    
    return redirect(f'/shows')




def viewShow(request, id):
    context = {
        "data_show": Show.objects.get(id=id)
    }
    return render(request, 'view_show.html', context)



def index_shows(request):
    context = {
        "data_show": Show.objects.all()
    }
    return render(request, 'shows.html', context)